#!/usr/bin/env node
// =============================================================================
// codeimage.mjs — Encode/Decode text into PNG pixel data
// =============================================================================
// Packs UTF-8 bytes into RGB channels (3 bytes per pixel, alpha=255).
// Format: [data bytes] [0x00 null terminator] [4-byte CRC32 big-endian] [padding]
//
// Usage:
//   node codeimage.mjs encode <input.js> [output.png]    Encode text file → PNG
//   node codeimage.mjs decode <input.png> [output.js]    Decode PNG → text file
//   node codeimage.mjs info   <input.png>                Show PNG payload info
//
// Options:
//   --size WxH            Force specific image dimensions (e.g. 300x300)
//   --verbose             Print processing details
//   --help, -h            Show this help
//
// Examples:
//   node codeimage.mjs encode app.bundle.js app.png
//   node codeimage.mjs decode app.png app.recovered.js
//   node codeimage.mjs info app.png
// =============================================================================

import { readFileSync, writeFileSync } from 'fs';
import { resolve, basename, extname } from 'path';
import { PNG } from 'pngjs';

// =============================================================================
// CRC32 — same implementation as the browser version
// =============================================================================

function crc32(bytes) {
    let crc = 0xFFFFFFFF;
    for (let i = 0; i < bytes.length; i++) {
        crc ^= bytes[i];
        for (let b = 0; b < 8; b++) {
            crc = (crc >>> 1) ^ (crc & 1 ? 0xEDB88320 : 0);
        }
    }
    return (crc ^ 0xFFFFFFFF) >>> 0;
}

// =============================================================================
// Encode — text file → PNG
// =============================================================================

function encode(inputPath, outputPath, opts) {
    const log = opts.verbose ? (...a) => console.log(...a) : () => {};

    // Read input as UTF-8, convert to bytes
    const text = readFileSync(inputPath, 'utf8');
    const bytes = Buffer.from(text, 'utf8');
    const checksum = crc32(bytes);

    log(`  Input:    ${basename(inputPath)}`);
    log(`  Text:     ${text.length} chars`);
    log(`  Bytes:    ${bytes.length} (UTF-8)`);
    log(`  CRC32:    ${checksum.toString(16).padStart(8, '0')}`);

    // Pack bytes into a flat array: 3 bytes per pixel (RGB), alpha=255
    const packed = [];
    let channel = 0;

    function packByte(b) {
        packed.push(b);
        channel++;
        if (channel === 3) {
            channel = 0;
            packed.push(255); // alpha
        }
    }

    // Data bytes
    for (let i = 0; i < bytes.length; i++) {
        packByte(bytes[i]);
    }

    // Null terminator
    packByte(0);

    // 4-byte CRC32 (big-endian)
    packByte((checksum >>> 24) & 0xFF);
    packByte((checksum >>> 16) & 0xFF);
    packByte((checksum >>> 8) & 0xFF);
    packByte(checksum & 0xFF);

    // Pad remaining channels in final pixel
    while (channel > 0 && channel < 3) {
        packed.push(0);
        channel++;
    }
    if (channel === 3) {
        channel = 0;
        packed.push(255); // alpha for final pixel
    }

    const totalPixels = packed.length / 4;

    // Calculate image dimensions
    let width, height;
    if (opts.size) {
        [width, height] = opts.size;
        if (width * height < totalPixels) {
            console.error(`Specified size ${width}x${height} (${width * height} px) too small for ${totalPixels} pixels`);
            process.exit(1);
        }
    } else {
        // Make it roughly square
        width = Math.ceil(Math.sqrt(totalPixels));
        height = Math.ceil(totalPixels / width);
    }

    log(`  Pixels:   ${totalPixels}`);
    log(`  Image:    ${width} x ${height}`);

    // Create PNG
    const png = new PNG({ width, height });

    // Copy packed data into the PNG buffer
    for (let i = 0; i < packed.length; i++) {
        png.data[i] = packed[i];
    }

    // Fill remaining pixels with transparent black (padding)
    for (let i = packed.length; i < width * height * 4; i += 4) {
        png.data[i] = 0;       // R
        png.data[i + 1] = 0;   // G
        png.data[i + 2] = 0;   // B
        png.data[i + 3] = 255; // A — keep opaque to avoid PNG filter issues
    }

    // Write PNG
    const pngBuffer = PNG.sync.write(png);
    writeFileSync(outputPath, pngBuffer);

    const sizeKB = (pngBuffer.length / 1024).toFixed(1);
    console.log(`\n✅ Encoded successfully`);
    console.log(`   Input:    ${basename(inputPath)} (${bytes.length} bytes)`);
    console.log(`   Output:   ${basename(outputPath)} (${sizeKB} KB)`);
    console.log(`   Image:    ${width} x ${height} (${totalPixels} pixels used)`);
    console.log(`   CRC32:    ${checksum.toString(16).padStart(8, '0')}\n`);
}

// =============================================================================
// Decode — PNG → text file
// =============================================================================

function decode(inputPath, outputPath, opts) {
    const log = opts.verbose ? (...a) => console.log(...a) : () => {};

    // Read PNG
    const pngBuffer = readFileSync(inputPath);
    const png = PNG.sync.read(pngBuffer);

    log(`  Image:    ${png.width} x ${png.height}`);

    // Unpack RGB bytes (skip alpha channel)
    const rawBytes = [];
    for (let i = 0; i < png.data.length; i += 4) {
        rawBytes.push(png.data[i]);       // R
        rawBytes.push(png.data[i + 1]);   // G
        rawBytes.push(png.data[i + 2]);   // B
    }

    // Find null terminator
    let nullIndex = -1;
    for (let i = 0; i < rawBytes.length; i++) {
        if (rawBytes[i] === 0) {
            nullIndex = i;
            break;
        }
    }

    if (nullIndex === -1) {
        console.error('❌ No null terminator found — image may not contain encoded data');
        process.exit(1);
    }

    // Extract data bytes (before null) and CRC32 (4 bytes after null)
    const dataBytes = Buffer.from(rawBytes.slice(0, nullIndex));
    const storedChecksum = (
        (rawBytes[nullIndex + 1] << 24) |
        (rawBytes[nullIndex + 2] << 16) |
        (rawBytes[nullIndex + 3] << 8) |
        (rawBytes[nullIndex + 4])
    ) >>> 0;

    const computedChecksum = crc32(dataBytes);

    log(`  Data:     ${dataBytes.length} bytes`);
    log(`  CRC32:    stored=${storedChecksum.toString(16).padStart(8, '0')} computed=${computedChecksum.toString(16).padStart(8, '0')}`);

    if (storedChecksum !== computedChecksum) {
        console.error(`❌ CRC32 mismatch! Image data is corrupted.`);
        console.error(`   Stored:   ${storedChecksum.toString(16).padStart(8, '0')}`);
        console.error(`   Computed: ${computedChecksum.toString(16).padStart(8, '0')}`);
        process.exit(1);
    }

    // Decode UTF-8
    const text = dataBytes.toString('utf8');

    // Write output
    writeFileSync(outputPath, text, 'utf8');

    const sizeKB = (pngBuffer.length / 1024).toFixed(1);
    console.log(`\n✅ Decoded successfully`);
    console.log(`   Input:    ${basename(inputPath)} (${sizeKB} KB, ${png.width}x${png.height})`);
    console.log(`   Output:   ${basename(outputPath)} (${dataBytes.length} bytes, ${text.length} chars)`);
    console.log(`   CRC32:    ${computedChecksum.toString(16).padStart(8, '0')} ✓\n`);
}

// =============================================================================
// Info — show PNG payload details without extracting
// =============================================================================

function info(inputPath, opts) {
    const pngBuffer = readFileSync(inputPath);
    const png = PNG.sync.read(pngBuffer);

    // Unpack RGB bytes
    const rawBytes = [];
    for (let i = 0; i < png.data.length; i += 4) {
        rawBytes.push(png.data[i]);
        rawBytes.push(png.data[i + 1]);
        rawBytes.push(png.data[i + 2]);
    }

    // Find null terminator
    let nullIndex = -1;
    for (let i = 0; i < rawBytes.length; i++) {
        if (rawBytes[i] === 0) { nullIndex = i; break; }
    }

    const sizeKB = (pngBuffer.length / 1024).toFixed(1);
    const totalPixels = png.width * png.height;

    console.log(`\n📦 PNG Payload Info`);
    console.log(`   File:      ${basename(inputPath)} (${sizeKB} KB)`);
    console.log(`   Image:     ${png.width} x ${png.height} (${totalPixels} pixels)`);

    if (nullIndex === -1) {
        console.log(`   Payload:   No null terminator found — may not contain encoded data\n`);
        return;
    }

    const dataBytes = Buffer.from(rawBytes.slice(0, nullIndex));
    const storedChecksum = (
        (rawBytes[nullIndex + 1] << 24) |
        (rawBytes[nullIndex + 2] << 16) |
        (rawBytes[nullIndex + 3] << 8) |
        (rawBytes[nullIndex + 4])
    ) >>> 0;
    const computedChecksum = crc32(dataBytes);
    const pixelsUsed = Math.ceil((nullIndex + 5) / 3);  // data + null + 4 CRC bytes

    console.log(`   Payload:   ${dataBytes.length} bytes (${dataBytes.toString('utf8').length} chars)`);
    console.log(`   Pixels:    ${pixelsUsed} used / ${totalPixels} total (${(pixelsUsed / totalPixels * 100).toFixed(1)}%)`);
    console.log(`   CRC32:     ${storedChecksum.toString(16).padStart(8, '0')} ${storedChecksum === computedChecksum ? '✓' : '✗ MISMATCH'}`);
    console.log(`   Preview:   ${dataBytes.toString('utf8').substring(0, 80)}...`);
    console.log('');
}

// =============================================================================
// CLI
// =============================================================================

function printUsage() {
    console.log(`
  codeimage.mjs — Encode/Decode text into PNG pixel data

  Usage:
    node codeimage.mjs encode <input.js> [output.png]    Text → PNG
    node codeimage.mjs decode <input.png> [output.js]    PNG → Text
    node codeimage.mjs info   <input.png>                Show payload info

  Options:
    --size WxH       Force image dimensions (e.g. 300x300)
    --verbose        Print processing details
    -h, --help       Show this help
`);
}

function parseArgs(argv) {
    const args = argv.slice(2);
    const opts = { command: null, input: null, output: null, size: null, verbose: false };
    const positional = [];

    for (let i = 0; i < args.length; i++) {
        switch (args[i]) {
            case '--size': {
                const parts = args[++i].split('x').map(Number);
                if (parts.length !== 2 || parts.some(isNaN)) {
                    console.error('Invalid --size format. Use WxH (e.g. 300x300)');
                    process.exit(1);
                }
                opts.size = parts;
                break;
            }
            case '--verbose': opts.verbose = true; break;
            case '--help': case '-h': printUsage(); process.exit(0);
            default:
                if (args[i].startsWith('-')) {
                    console.error(`Unknown option: ${args[i]}`);
                    process.exit(1);
                }
                positional.push(args[i]);
        }
    }

    if (positional.length < 2) { printUsage(); process.exit(1); }

    opts.command = positional[0];
    opts.input = resolve(positional[1]);

    if (positional[2]) {
        opts.output = resolve(positional[2]);
    } else {
        // Default output name
        const base = basename(opts.input, extname(opts.input));
        if (opts.command === 'encode') {
            opts.output = resolve(base + '.png');
        } else if (opts.command === 'decode') {
            opts.output = resolve(base + '.js');
        }
    }

    return opts;
}

// =============================================================================
// Run
// =============================================================================

const opts = parseArgs(process.argv);

switch (opts.command) {
    case 'encode':
        encode(opts.input, opts.output, opts);
        break;
    case 'decode':
        decode(opts.input, opts.output, opts);
        break;
    case 'info':
        info(opts.input, opts);
        break;
    default:
        console.error(`Unknown command: ${opts.command}`);
        printUsage();
        process.exit(1);
}
