# appbundler

Bundle multi-file web apps into a single launchable JS function, with optional obfuscation and PNG encoding.

## Setup

```
cd C:\tools\appbundler
npm install
npm link
```

That's it. `bundle` and `codeimage` are now available globally.

## Commands

### bundle

Takes an HTML entry file and produces a single `.js` file containing a launch function that hydrates the entire app.

```
bundle index.html
bundle index.html --out app.bundle.js --name launchApp
bundle index.html --out app.bundle.js --name launchApp --entry main --verbose
```

**Options:**
- `--out <file>` — Output path (default: `<entry>.bundle.js`)
- `--name <id>` — Launch function name (default: `launchApp`)
- `--entry <fn>` — App entry point called after hydration (default: auto-detect from `onload`)
- `--no-entry` — Don't call any entry point
- `--verbose` — Show processing details

**Loader Directives** (for JS files that dynamically load other scripts):
```javascript
// @bundle-expand              Activate expansion for this file
// @bundle-basedir js          Base directory for .js file paths
// @bundle-entry main          Entry point function (overrides onload)
// @bundle-ignore-start        Start stripping here
// @bundle-ignore-end          Stop stripping here
```

### codeimage

Encode text into PNG pixel data (RGB channels, CRC32 integrity check).

```
codeimage encode app.bundle.js app.png
codeimage decode app.png app.recovered.js
codeimage info app.png
```

**Options:**
- `--size WxH` — Force image dimensions (e.g. `300x300`)
- `--verbose` — Show processing details

## Full Pipeline

```batch
bundle index.html --out app.bundle.js --name launchApp
npx javascript-obfuscator app.bundle.js --output app.min.js
codeimage encode app.min.js app.png
```

Use https://obfuscator.io/legacy-playground to play with targetted obfuscating

## Updating

Since `npm link` creates symlinks, edits to the scripts in this folder take effect immediately — no reinstall needed.

## Uninstall

```
npm unlink -g appbundler
```
