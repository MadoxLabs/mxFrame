#!/usr/bin/env node
// =============================================================================
// bundle.mjs — Web App Bundler
// =============================================================================
// Takes a multi-file web app (HTML + CSS + JS) and produces a single .js file
// containing a launchApp() function. When called, that function hydrates the
// current document with all styles, markup, and scripts — ready for a
// bootloader to fetch and execute.
//
// Usage:
//   node bundle.mjs <entry.html> [options]
//
// Options:
//   --out <file>          Output file path (default: <entry>.bundle.js)
//   --name <identifier>   Function name exported (default: launchApp)
//   --entry <fn>          App entry point to call after hydration (default: auto-detect from onload)
//   --no-entry            Don't call any entry point function after hydration
//   --format iife|export  Output format (default: iife — self-registering)
//   --verbose             Print detailed processing info
//
// Loader/Expand Directives (placed in .js files that dynamically load other scripts):
//   // @bundle-expand          Marks this file as a loader — triggers expansion
//   // @bundle-basedir <dir>   Base directory for .js file paths (multiple allowed, searched in order)
//   // @bundle-entry <fn>      Entry point function to call after hydration (overrides onload)
//   // @bundle-ignore-start    Start of a block to strip from the bundle
//   // @bundle-ignore-end      End of a block to strip from the bundle
//
// Directives work in both external .js files and inline <script> blocks.
// The bundler scans the loader for string arrays containing .js paths,
// resolves them relative to @bundle-basedir, and inlines them in order.
// Code outside @bundle-ignore blocks is preserved (e.g. namespace declarations).
//
// Examples:
//   node bundle.mjs index.html
//   node bundle.mjs index.html --out timeline.bundle.js --name launchTimeline
//   node bundle.mjs app.html --entry init --verbose
// =============================================================================

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { resolve, dirname, basename, extname, relative } from 'path';

// =============================================================================
// CLI Argument Parsing
// =============================================================================

function parseArgs(argv) {
    const args = argv.slice(2);
    const opts = {
        entry: null,        // HTML entry file
        out: null,          // output .js file
        name: 'launchApp',  // exported function name
        entryFn: null,      // app entry point function (auto-detected if null)
        noEntry: false,     // skip calling entry function
        format: 'iife',     // output format
        verbose: false,
        test: false,        // dry run — list files in bundle order, no output
        raw: false,         // pass 1 — output combined JS only, no wrapper
        jsFile: null,       // pass 2 — use pre-processed JS instead of collecting from HTML
    };
    const positional = [];

    for (let i = 0; i < args.length; i++) {
        switch (args[i]) {
            case '--out':     opts.out = args[++i]; break;
            case '--name':    opts.name = args[++i]; break;
            case '--entry':   opts.entryFn = args[++i]; break;
            case '--no-entry': opts.noEntry = true; break;
            case '--format':  opts.format = args[++i]; break;
            case '--verbose': opts.verbose = true; break;
            case '--test':    opts.test = true; break;
            case '--raw':     opts.raw = true; break;
            case '--js':      opts.jsFile = resolve(args[++i]); break;
            case '--help': case '-h': printUsage(); process.exit(0);
            default:
                if (args[i].startsWith('-')) {
                    console.error(`Unknown option: ${args[i]}`);
                    process.exit(1);
                }
                positional.push(args[i]);
        }
    }

    if (positional.length === 0) {
        printUsage();
        process.exit(1);
    }

    opts.entry = resolve(positional[0]);

    if (!opts.out) {
        const base = basename(opts.entry, extname(opts.entry));
        if (opts.raw) {
            opts.out = resolve(dirname(opts.entry), `${base}.raw.js`);
        } else {
            opts.out = resolve(dirname(opts.entry), `${base}.bundle.js`);
        }
    } else {
        opts.out = resolve(opts.out);
    }

    return opts;
}

function printUsage() {
    console.log(`
  bundle.mjs — Web App Bundler

  Usage:  node bundle.mjs <entry.html> [options]

  Options:
    --out <file>          Output path (default: <entry>.bundle.js)
    --name <identifier>   Launch function name (default: launchApp)
    --entry <fn>          Entry point function called after hydration
    --no-entry            Don't auto-call any entry point
    --raw                 Pass 1: output combined JS only (no wrapper/CSS/HTML)
    --js <file>           Pass 2: use pre-processed JS file instead of collecting from HTML
    --format iife|export  Output format (default: iife)
    --verbose             Print processing details
    --test                Dry run — list files in bundle order, no output
    -h, --help            Show this help

  Two-Pass Workflow (for obfuscation):
    bundle index.html --raw --out app.raw.js
    npx javascript-obfuscator app.raw.js --output app.obf.js
    bundle index.html --js app.obf.js --out app.bundle.js
`);
}

// =============================================================================
// HTML Parsing Helpers
// =============================================================================

// Match all tags of a given type (self-closing and paired)
function findTags(html, tagName) {
    const results = [];
    // Match both self-closing and paired tags
    const pattern = new RegExp(
        `<${tagName}(\\s[^>]*)?\\/?>([\\s\\S]*?)<\\/${tagName}>|<${tagName}(\\s[^>]*)?\\/?>`,
        'gi'
    );
    let m;
    while ((m = pattern.exec(html)) !== null) {
        const attrsRaw = m[1] || m[3] || '';
        const inner = m[2] || '';
        results.push({
            full: m[0],
            attrs: parseAttrs(attrsRaw),
            attrsRaw: attrsRaw.trim(),
            inner: inner,
            index: m.index,
        });
    }
    return results;
}

// Parse HTML attributes from a string like: rel="stylesheet" href="foo.css"
function parseAttrs(str) {
    const attrs = {};
    const pattern = /([a-zA-Z_][\w-]*)\s*(?:=\s*(?:"([^"]*)"|'([^']*)'|(\S+)))?/g;
    let m;
    while ((m = pattern.exec(str)) !== null) {
        attrs[m[1].toLowerCase()] = m[2] ?? m[3] ?? m[4] ?? true;
    }
    return attrs;
}

// Extract content between <head>...</head>
function extractHead(html) {
    const m = html.match(/<head[^>]*>([\s\S]*?)<\/head>/i);
    return m ? m[1] : '';
}

// Extract content between <body>...</body>, plus body tag attributes
function extractBody(html) {
    const m = html.match(/<body([^>]*)>([\s\S]*?)<\/body>/i);
    return m ? { attrs: parseAttrs(m[1]), attrsRaw: m[1].trim(), inner: m[2] } : null;
}

// =============================================================================
// File Resolution
// =============================================================================

function readLocalFile(href, baseDir, verbose) {
    // Skip external URLs
    if (/^https?:\/\//i.test(href) || href.startsWith('//')) {
        return null;
    }
    // Skip data URIs
    if (href.startsWith('data:')) return null;

    const filePath = resolve(baseDir, href);
    if (!existsSync(filePath)) {
        console.warn(`  ⚠  File not found: ${href} (resolved to ${filePath})`);
        return null;
    }
    if (verbose) console.log(`  📄 Reading: ${relative(process.cwd(), filePath)}`);
    // Strip UTF-8 BOM (U+FEFF) — editors like VS Code and Notepad can add these,
    // and they break CSS selectors and JS parsing when embedded in a bundle
    return readFileSync(filePath, 'utf8').replace(/^\uFEFF/, '');
}

function isExternalUrl(href) {
    return /^https?:\/\//i.test(href) || (href && href.startsWith('//'));
}

// =============================================================================
// @bundle-expand Processing
// =============================================================================
// Handles JS files that contain a custom loader mechanism. When a JS file has
// a // @bundle-expand directive, the bundler will:
//   1. Parse // @bundle-basedir <dir> for the base path of referenced files
//   2. Scan string arrays for .js filenames to inline
//   3. Strip // @bundle-ignore-start ... // @bundle-ignore-end blocks
//   4. Return the cleaned file + list of files to expand
//
// This lets loader scripts like noisetool.js keep their runtime-needed code
// (e.g. namespace declarations) while stripping the dynamic loading machinery.
// =============================================================================

function processExpandableFile(content, fileDir, verbose) {
    // Check for @bundle-expand directive
    if (!/@bundle-expand\b/.test(content)) {
        return null; // not an expandable file
    }

    const log = verbose ? (...a) => console.log(...a) : () => {};
    log(`  🔄 @bundle-expand directive found`);

    // Parse all @bundle-basedir directives (searched in order until file is found)
    const basedirMatches = [...content.matchAll(/@bundle-basedir\s+(\S+)/g)];
    const expandBaseDirs = basedirMatches.length > 0
        ? basedirMatches.map(m => resolve(fileDir, m[1]))
        : [fileDir];
    for (const dir of expandBaseDirs) {
        log(`  📂 Expand base dir: ${relative(process.cwd(), dir)}`);
    }

    // Parse @bundle-entry for the app's real entry point function
    const entryMatch = content.match(/@bundle-entry\s+([a-zA-Z_$][\w$.]*)/);
    const entryFn = entryMatch ? entryMatch[1] : null;
    if (entryFn) log(`  🚀 Entry point: ${entryFn}()`);

    // Scan for string arrays containing .js file paths.
    // Matches: ["file.js", "dir/file.js"] across single or multi-line arrays
    const expandFiles = [];
    const arrayPattern = /\[([^\]]*)\]/gs;
    let arrMatch;
    while ((arrMatch = arrayPattern.exec(content)) !== null) {
        const arrayBody = arrMatch[1];
        // Look for .js string literals inside this array
        const stringPattern = /["']([^"']*\.js)["']/g;
        let strMatch;
        const filesInThisArray = [];
        while ((strMatch = stringPattern.exec(arrayBody)) !== null) {
            filesInThisArray.push(strMatch[1]);
        }
        // Only treat as a file list if it contained at least one .js reference
        if (filesInThisArray.length > 0) {
            expandFiles.push(...filesInThisArray);
        }
    }
    log(`  📋 Found ${expandFiles.length} file(s) to expand`);

    // Strip @bundle-ignore-start ... @bundle-ignore-end blocks
    let cleaned = content.replace(
        /\/\/\s*@bundle-ignore-start[\s\S]*?\/\/\s*@bundle-ignore-end[^\n]*/g,
        ''
    );

    // Remove the directive comment lines themselves
    cleaned = cleaned.replace(/\/\/\s*@bundle-expand[^\n]*/g, '');
    cleaned = cleaned.replace(/\/\/\s*@bundle-basedir[^\n]*/g, '');
    cleaned = cleaned.replace(/\/\/\s*@bundle-entry[^\n]*/g, '');

    // Collapse runs of 3+ blank lines down to 2
    cleaned = cleaned.replace(/\n{3,}/g, '\n\n').trim();

    return {
        cleaned,        // the loader file with ignore blocks + directives removed
        expandFiles,    // ordered list of .js paths to inline
        expandBaseDirs, // resolved base directories to search (in order)
        entryFn,        // entry point function name from @bundle-entry (or null)
    };
}

// Search multiple base directories for a file, returning the first match
function readFromBaseDirs(href, baseDirs, verbose) {
    for (const dir of baseDirs) {
        const filePath = resolve(dir, href);
        if (existsSync(filePath)) {
            if (verbose) console.log(`  📄 Reading: ${relative(process.cwd(), filePath)}`);
            return readFileSync(filePath, 'utf8').replace(/^\uFEFF/, '');
        }
    }
    console.warn(`  ⚠  File not found: ${href} (searched ${baseDirs.length} base dir(s))`);
    return null;
}

// Read a JS file and, if it's expandable, return cleaned content + expanded
// file contents as an array of { label, code } blocks in the correct order,
// plus any @bundle-entry directive found.
function inlineJsFile(src, baseDir, verbose) {
    const js = readLocalFile(src, baseDir, verbose);
    if (js === null) return { blocks: [], entryFn: null };

    const fileDir = dirname(resolve(baseDir, src));
    return processJsContent(js, src, fileDir, verbose);
}

// Process JS content (from a file or inline script) for @bundle-expand directives.
// Returns { blocks: [{label, code}], entryFn: string|null }
function processJsContent(content, label, fileDir, verbose) {
    const expanded = processExpandableFile(content, fileDir, verbose);

    if (!expanded) {
        // Normal JS — just return it as-is
        return { blocks: [{ label, code: content }], entryFn: null };
    }

    // Expandable — return cleaned content + all expanded files
    const blocks = [];

    if (expanded.cleaned) {
        blocks.push({ label: `${label} (loader)`, code: expanded.cleaned });
    }

    for (const file of expanded.expandFiles) {
        const expandedJs = readFromBaseDirs(file, expanded.expandBaseDirs, verbose);
        if (expandedJs !== null) {
            blocks.push({ label: file, code: expandedJs });
        }
    }

    return { blocks, entryFn: expanded.entryFn };
}

// =============================================================================
// Escaping for Template Literal Embedding
// =============================================================================

function escapeForTemplateLiteral(str) {
    return str
        .replace(/\\/g, '\\\\')          // backslashes first
        .replace(/`/g, '\\`')            // backticks
        .replace(/\$\{/g, '\\${');       // template expressions
}

// Prevent </script> inside a string from closing an outer <script> tag
// Split it into '</' + 'script>' which is functionally identical
function escapeScriptClose(str) {
    return str.replace(/<\/script>/gi, '<\\/script>');
}

// =============================================================================
// Core Bundling Logic
// =============================================================================

function bundle(opts) {
    const startTime = Date.now();
    const log = opts.verbose ? (...a) => console.log(...a) : () => {};

    // --- Read entry HTML ---
    if (!existsSync(opts.entry)) {
        console.error(`Entry file not found: ${opts.entry}`);
        process.exit(1);
    }
    const html = readFileSync(opts.entry, 'utf8').replace(/^\uFEFF/, '');
    const baseDir = dirname(opts.entry);

    log(`\n📦 Bundling: ${relative(process.cwd(), opts.entry)}`);

    // --- Collect resources ---
    const externalLinks = [];   // { tag, href, attrs } - external link elements to create at runtime
    const metaTags = [];        // raw meta tag strings to inject
    const cssBlocks = [];       // collected CSS content (in order)
    const jsBlocks = [];        // collected JS content (in order)
    let title = '';
    let bodyHtml = '';
    let entryFn = opts.entryFn;
    let entrySource = opts.entryFn ? 'cli' : null;  // track where entryFn came from

    // --- Process <head> ---
    const head = extractHead(html);
    log('\n🔍 Processing <head>...');

    // Title
    const titleTags = findTags(head, 'title');
    if (titleTags.length > 0) {
        title = titleTags[0].inner.trim();
        log(`  📌 Title: "${title}"`);
    }

    // Meta tags — store as { raw, attrs } with attributes parsed from the tag
    const metas = head.match(/<meta[^>]*\/?>/gi) || [];
    for (const meta of metas) {
        const attrStr = meta.replace(/^<meta\s*/i, '').replace(/\/?>$/, '');
        metaTags.push({ raw: meta, attrs: parseAttrs(attrStr) });
        log(`  📌 Meta: ${meta.substring(0, 60)}...`);
    }

    // Link tags
    const links = findTags(head, 'link');
    for (const link of links) {
        const { attrs } = link;
        const rel = (attrs.rel || '').toLowerCase();
        const href = attrs.href || '';

        if (rel === 'stylesheet') {
            if (isExternalUrl(href)) {
                // External stylesheet — load dynamically at runtime
                externalLinks.push({ type: 'stylesheet', href, attrs });
                log(`  🌐 External CSS: ${href}`);
            } else {
                // Local stylesheet — read and inline
                const css = readLocalFile(href, baseDir, opts.verbose);
                if (css !== null) {
                    cssBlocks.push(`/* === ${href} === */\n${css}`);
                    log(`  ✅ Inlined CSS: ${href} (${css.length} chars)`);
                }
            }
        } else if (rel === 'preconnect' || rel === 'dns-prefetch') {
            externalLinks.push({ type: rel, href, attrs });
            log(`  🔗 ${rel}: ${href}`);
        } else if (rel === 'icon' || rel === 'shortcut icon') {
            externalLinks.push({ type: 'icon', href, attrs });
            log(`  🔗 Icon: ${href}`);
        } else {
            // Other link types — preserve as external
            externalLinks.push({ type: rel || 'link', href, attrs });
            log(`  🔗 Link [${rel}]: ${href}`);
        }
    }

    // Inline <style> blocks in head
    const headStyles = findTags(head, 'style');
    for (const style of headStyles) {
        if (style.inner.trim()) {
            cssBlocks.push(`/* === inline <style> === */\n${style.inner}`);
            log(`  ✅ Inlined <style> (${style.inner.length} chars)`);
        }
    }

    // Script tags in head
    const headScripts = findTags(head, 'script');
    for (const script of headScripts) {
        const src = script.attrs.src || '';
        const scriptType = (script.attrs.type || '').toLowerCase();

        // Skip non-JS script types (e.g. application/json, ld+json)
        if (scriptType && scriptType !== 'text/javascript' && scriptType !== 'application/javascript' && scriptType !== 'module') {
            log(`  ⏭  Skipping non-JS script: type="${scriptType}"`);
            continue;
        }

        if (src) {
            if (isExternalUrl(src)) {
                externalLinks.push({ type: 'script', href: src, attrs: script.attrs });
                log(`  🌐 External JS (head): ${src}`);
            } else {
                const result = inlineJsFile(src, baseDir, opts.verbose);
                for (const block of result.blocks) {
                    jsBlocks.push(`// === ${block.label} ===\n${block.code}`);
                    log(`  ✅ Inlined JS (head): ${block.label} (${block.code.length} chars)`);
                }
                if (result.entryFn && entrySource !== 'cli') {
                    entryFn = result.entryFn;
                    entrySource = 'directive';
                }
            }
        } else if (script.inner.trim()) {
            // Check for @bundle-expand in inline scripts too
            const result = processJsContent(script.inner, 'inline <script> (head)', baseDir, opts.verbose);
            for (const block of result.blocks) {
                jsBlocks.push(`// === ${block.label} ===\n${block.code}`);
                log(`  ✅ Inlined JS (head): ${block.label} (${block.code.length} chars)`);
            }
            if (result.entryFn && entrySource !== 'cli') {
                entryFn = result.entryFn;
                entrySource = 'directive';
            }
        }
    }

    // --- Process <body> ---
    log('\n🔍 Processing <body>...');
    const body = extractBody(html);
    if (!body) {
        console.error('No <body> tag found in entry HTML.');
        process.exit(1);
    }

    // Detect entry point from onload
    if (!entryFn && !opts.noEntry && body.attrs.onload) {
        const onload = body.attrs.onload;
        // Extract function name from "main();" or "init()" etc.
        const fnMatch = onload.match(/^([a-zA-Z_$][\w$.]*)\s*\(\s*\)\s*;?\s*$/);
        if (fnMatch) {
            entryFn = fnMatch[1];
            entrySource = 'onload';
            log(`  📌 Entry point detected from onload: ${entryFn}()`);
        } else {
            // Complex onload — wrap it as an inline call
            jsBlocks.push(`// === body onload ===\n(function(){ ${onload} })();`);
            log(`  📌 Complex onload preserved as inline JS`);
        }
    }

    // Extract body HTML, removing <script> tags from it
    let bodyContent = body.inner;

    // Track how many JS blocks came from <head> so we can separate them later
    const headJsBlockCount = jsBlocks.length;

    // Find and process all script tags in body
    const bodyScripts = findTags(bodyContent, 'script');
    // Process in reverse order so indices stay valid as we remove them
    const sortedScripts = [...bodyScripts].sort((a, b) => b.index - a.index);

    for (const script of sortedScripts) {
        const src = script.attrs.src || '';

        // Collect external scripts (these need to be noted regardless of order)
        if (src && isExternalUrl(src)) {
            externalLinks.push({ type: 'script', href: src, attrs: script.attrs });
            log(`  🌐 External JS (body): ${src}`);
        }

        // Remove the script tag from body HTML
        bodyContent = bodyContent.substring(0, script.index) +
                      bodyContent.substring(script.index + script.full.length);
    }

    bodyHtml = bodyContent.trim();
    log(`  📌 Body HTML: ${bodyHtml.length} chars`);

    // --- Handle script ordering for body scripts ---
    // Body scripts were processed in reverse order for removal but need original order.
    // Re-sort: we actually pushed them in reverse, so we need to fix this.
    // Let's redo this properly with a forward pass.

    // Actually, the issue is we sorted scripts in reverse for safe removal from bodyContent,
    // but pushed to jsBlocks in reverse order. Let's fix by collecting body scripts separately.

    // Reset and redo body scripts in forward order
    const bodyJsBlocks = [];
    for (const script of bodyScripts) {  // original forward order
        const src = script.attrs.src || '';
        const scriptType = (script.attrs.type || '').toLowerCase();
        if (scriptType && scriptType !== 'text/javascript' && scriptType !== 'application/javascript' && scriptType !== 'module') continue;

        if (src) {
            if (!isExternalUrl(src)) {
                const result = inlineJsFile(src, baseDir, opts.verbose);
                for (const block of result.blocks) {
                    bodyJsBlocks.push(`// === ${block.label} ===\n${block.code}`);
                    log(`  ✅ Inlined JS (body): ${block.label} (${block.code.length} chars)`);
                }
                if (result.entryFn && entrySource !== 'cli') {
                    entryFn = result.entryFn;
                    entrySource = 'directive';
                }
            }
        } else if (script.inner.trim()) {
            // Check for @bundle-expand in inline scripts too
            const result = processJsContent(script.inner, 'inline <script> (body)', baseDir, opts.verbose);
            for (const block of result.blocks) {
                bodyJsBlocks.push(`// === ${block.label} ===\n${block.code}`);
                log(`  ✅ Inlined JS (body): ${block.label} (${block.code.length} chars)`);
            }
            if (result.entryFn && entrySource !== 'cli') {
                entryFn = result.entryFn;
                entrySource = 'directive';
            }
        }
    }

    // Rebuild jsBlocks: keep head entries (correct order), replace body entries
    // with the forward-pass bodyJsBlocks (also correct order)
    const headJsBlocks = jsBlocks.slice(0, headJsBlockCount);
    const finalJsBlocks = [...headJsBlocks, ...bodyJsBlocks];

    // --- Test mode: list files and exit ---
    if (opts.test) {
        // Extract labels from block headers (format: "// === label ===\n...")
        const extractLabel = (block) => {
            const m = block.match(/^(?:\/\/ === |\/\* === )(.+?)(?:===|=== \*\/)/);
            return m ? m[1].trim() : '(inline)';
        };

        console.log(`\n📋 Bundle order for: ${relative(process.cwd(), opts.entry)}\n`);

        if (cssBlocks.length > 0) {
            console.log('  CSS:');
            for (const block of cssBlocks) console.log(`    ${extractLabel(block)}`);
        }

        if (finalJsBlocks.length > 0) {
            console.log('  JS:');
            for (const block of finalJsBlocks) console.log(`    ${extractLabel(block)}`);
        }

        if (externalLinks.length > 0) {
            console.log('  External:');
            for (const ext of externalLinks) console.log(`    [${ext.type}] ${ext.href}`);
        }

        if (entryFn && !opts.noEntry) {
            console.log(`\n  Entry: ${entryFn}()`);
        }

        console.log(`\n  Total: ${cssBlocks.length} CSS, ${finalJsBlocks.length} JS, ${externalLinks.length} external\n`);
        return;
    }

    // --- Raw mode: output combined JS only (pass 1) ---
    if (opts.raw) {
        const combinedJs = finalJsBlocks.join('\n\n');
        writeFileSync(opts.out, combinedJs, 'utf8');

        const sizeKB = (Buffer.byteLength(combinedJs) / 1024).toFixed(1);
        console.log(`\n✅ Raw JS combined`);
        console.log(`   Output:    ${relative(process.cwd(), opts.out)}`);
        console.log(`   Size:      ${sizeKB} KB`);
        console.log(`   Sources:   ${finalJsBlocks.length}`);
        if (entryFn && !opts.noEntry) {
            console.log(`   Entry:     ${entryFn}()`);
        }
        console.log('');
        return;
    }

    // --- Generate Output ---
    log('\n📝 Generating bundle...');

    const combinedCss = cssBlocks.join('\n\n');

    // If --js was provided, use the pre-processed JS file (e.g. obfuscated)
    // instead of the JS collected from the HTML
    let combinedJs;
    if (opts.jsFile) {
        if (!existsSync(opts.jsFile)) {
            console.error(`JS file not found: ${opts.jsFile}`);
            process.exit(1);
        }
        combinedJs = readFileSync(opts.jsFile, 'utf8').replace(/^\uFEFF/, '');
        log(`  JS: using pre-processed file: ${relative(process.cwd(), opts.jsFile)} (${combinedJs.length} chars)`);
    } else {
        combinedJs = finalJsBlocks.join('\n\n');
    }

    log(`  CSS: ${combinedCss.length} chars`);
    log(`  JS:  ${combinedJs.length} chars`);
    log(`  HTML: ${bodyHtml.length} chars`);
    log(`  External resources: ${externalLinks.length}`);

    // Encode CSS and JS as Base64 — obfuscator-proof, no escaping needed.
    // HTML body still uses template literal since it goes into innerHTML, not a script.
    const cssBase64 = Buffer.from(combinedCss).toString('base64');
    const jsBase64 = Buffer.from(combinedJs).toString('base64');
    const htmlEscaped = escapeForTemplateLiteral(bodyHtml);

    // Build external resource injection code
    let externalInjection = '';
    for (const ext of externalLinks) {
        if (ext.type === 'stylesheet') {
            externalInjection += `
  (function() {
    var l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = '${ext.href}';
    ${ext.attrs.crossorigin ? "l.crossOrigin = '" + ext.attrs.crossorigin + "';" : ''}
    document.head.appendChild(l);
  })();`;
        } else if (ext.type === 'preconnect' || ext.type === 'dns-prefetch') {
            externalInjection += `
  (function() {
    var l = document.createElement('link');
    l.rel = '${ext.type}';
    l.href = '${ext.href}';
    ${ext.attrs.crossorigin ? "l.crossOrigin = '" + ext.attrs.crossorigin + "';" : ''}
    document.head.appendChild(l);
  })();`;
        } else if (ext.type === 'icon') {
            const iconType = ext.attrs.type ? `l.type = '${ext.attrs.type}';` : '';
            externalInjection += `
  (function() {
    var l = document.createElement('link');
    l.rel = '${ext.attrs.rel || 'icon'}';
    l.href = '${ext.href}';
    ${iconType}
    document.head.appendChild(l);
  })();`;
        } else if (ext.type === 'script') {
            externalInjection += `
  (function() {
    var s = document.createElement('script');
    s.src = '${ext.href}';
    ${ext.attrs.crossorigin ? "s.crossOrigin = '" + ext.attrs.crossorigin + "';" : ''}
    ${ext.attrs.defer ? 's.defer = true;' : ''}
    ${ext.attrs.async ? 's.async = true;' : ''}
    document.head.appendChild(s);
  })();`;
        } else {
            // Generic link element
            externalInjection += `
  (function() {
    var l = document.createElement('link');
    ${ext.attrs.rel ? "l.rel = '" + ext.attrs.rel + "';" : ''}
    ${ext.href ? "l.href = '" + ext.href + "';" : ''}
    document.head.appendChild(l);
  })();`;
        }
    }

    // Build entry point call — use window["name"]() bracket notation
    // so the obfuscator can't rename the reference to the inner function
    let entryCall = '';
    if (entryFn && !opts.noEntry) {
        entryCall = `\n  // --- Boot ---\n  window["${entryFn}"]();`;
    }

    // Build the output JS file
    let output = '';

    output += `// =============================================================================\n`;
    output += `// ${title || basename(opts.entry, extname(opts.entry))} — Bundled App\n`;
    output += `// Generated by bundle.mjs on ${new Date().toISOString()}\n`;
    output += `// Source: ${basename(opts.entry)}\n`;
    output += `// =============================================================================\n\n`;

    output += `function ${opts.name}() {\n`;

    // Cleanup — remove any pre-existing styles, links, and scripts from <head>
    // so the bootloader's splash CSS (or anything else) doesn't bleed through
    output += `\n  // --- Cleanup ---\n`;
    output += `  // Remove bootloader/pre-existing styles so they don't conflict\n`;
    output += `  document.querySelectorAll('head style, head link[rel=\"stylesheet\"]').forEach(function(el) { el.remove(); });\n`;
    output += `  // Reset body attributes from bootloader\n`;
    output += `  document.body.removeAttribute('class');\n`;
    output += `  document.body.removeAttribute('style');\n`;

    // UTF-8-aware Base64 decode helper — atob() only handles Latin-1,
    // which mangles multi-byte characters like ✓ → ©
    output += `\n  // --- Base64 Decoder (UTF-8 safe) ---\n`;
    output += `  function _b64(s) { var b = atob(s), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return new TextDecoder().decode(a); }\n`;

    // Title
    if (title) {
        output += `\n  // --- Title ---\n`;
        output += `  document.title = '${title.replace(/'/g, "\\'")}';`;
    }

    // Meta tags
    if (metaTags.length > 0) {
        output += `\n\n  // --- Meta Tags ---\n`;
        for (const { attrs } of metaTags) {
            const parts = [];
            for (const [k, v] of Object.entries(attrs)) {
                if (v === true) parts.push(`m.setAttribute('${k}', '');`);
                else parts.push(`m.setAttribute('${k}', '${v.replace(/'/g, "\\'")}');`);
            }
            output += `  (function() { var m = document.createElement('meta'); ${parts.join(' ')} document.head.appendChild(m); })();\n`;
        }
    }

    // External resources (fonts, CDN scripts, etc.)
    if (externalInjection) {
        output += `\n  // --- External Resources ---${externalInjection}\n`;
    }

    // CSS
    if (combinedCss) {
        output += `\n  // --- Styles ---\n`;
        output += `  var _style = document.createElement('style');\n`;
        output += `  _style.textContent = _b64("${cssBase64}");\n`;
        output += `  document.head.appendChild(_style);\n`;
    }

    // Body HTML + attributes
    output += `\n  // --- Body HTML ---\n`;
    output += `  document.body.innerHTML = \`${htmlEscaped}\`;\n`;

    // Apply original <body> attributes (class, style, id, data-*, etc.)
    // Skip 'onload' since the entry point is handled separately
    const bodyAttrs = body.attrs || {};
    const bodyAttrEntries = Object.entries(bodyAttrs).filter(([k]) => k !== 'onload');
    if (bodyAttrEntries.length > 0) {
        output += `  // Restore original <body> tag attributes\n`;
        for (const [k, v] of bodyAttrEntries) {
            if (v === true) {
                output += `  document.body.setAttribute('${k}', '');\n`;
            } else {
                output += `  document.body.setAttribute('${k}', '${v.replace(/'/g, "\\'")}');\n`;
            }
        }
    }

    // JS — injected via <script> element for global scope
    if (combinedJs) {
        output += `\n  // --- Application JavaScript ---\n`;
        output += `  // Injected via <script> element so declarations land in global scope,\n`;
        output += `  // as required by inline event handlers in the HTML.\n`;
        output += `  var _script = document.createElement('script');\n`;
        output += `  _script.textContent = _b64("${jsBase64}");\n`;
        output += `  document.body.appendChild(_script);\n`;
    }

    // Entry point
    output += entryCall;

    output += `\n}\n`;

    // Ensure the launch function is globally accessible even if the obfuscator
    // wraps everything in an IIFE — bracket notation so the name string survives
    output += `window["${opts.name}"] = ${opts.name};\n`;

    // Escape any </script> that might appear in the output
    output = escapeScriptClose(output);

    // --- Write output ---
    writeFileSync(opts.out, output, 'utf8');

    const elapsed = Date.now() - startTime;
    const sizeKB = (Buffer.byteLength(output) / 1024).toFixed(1);

    console.log(`\n✅ Bundle complete!`);
    console.log(`   Output:    ${relative(process.cwd(), opts.out)}`);
    console.log(`   Size:      ${sizeKB} KB`);
    console.log(`   Function:  ${opts.name}()`);
    if (entryFn && !opts.noEntry) {
        console.log(`   Entry:     ${entryFn}()`);
    }
    console.log(`   CSS:       ${cssBlocks.length} source(s), ${combinedCss.length} chars`);
    console.log(`   JS:        ${finalJsBlocks.length} source(s), ${combinedJs.length} chars`);
    console.log(`   External:  ${externalLinks.length} resource(s)`);
    console.log(`   Time:      ${elapsed}ms\n`);
}

// =============================================================================
// Run
// =============================================================================

const opts = parseArgs(process.argv);
bundle(opts);
