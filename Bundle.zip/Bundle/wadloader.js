// =============================================================================
// wadloader.js — Client-Side WAD Asset Loader
// =============================================================================
// Fetches a .wad file, parses its manifest, and patches XMLHttpRequest and
// fetch() to transparently serve assets from memory. Game code doesn't need
// any modifications — requests for packed files are intercepted and served
// instantly from the WAD buffer.
//
// Usage:
//   <script src="wadloader.js"></script>
//   <script>
//     WadLoader.load('game.wad').then(function() {
//       // App can now request any packed file normally.
//       // XMLHttpRequest and fetch are patched to serve from the WAD.
//       main();
//     });
//   </script>
//
// API:
//   WadLoader.load(url)              Fetch & activate a WAD (returns Promise)
//   WadLoader.load(url, url2, ...)   Load multiple WADs
//   WadLoader.has(filename)          Check if a file is in any loaded WAD
//   WadLoader.get(filename)          Get raw ArrayBuffer for a file
//   WadLoader.getText(filename)      Get file contents as UTF-8 string
//   WadLoader.getBlob(filename, type) Get file as a Blob
//   WadLoader.getURL(filename, type) Get file as an Object URL (for images/audio)
//   WadLoader.list()                 List all loaded filenames
//   WadLoader.stats()                Get loading statistics
//   WadLoader.blobs()                List all created blob URLs (for debugging)
//   WadLoader.revokeAll()            Revoke all blob URLs (free memory)
// =============================================================================

var WadLoader = (function() {

    // =========================================================================
    // Internal State
    // =========================================================================

    var _entries = {};     // filename → { buffer, offset, size }
    var _loaded = [];      // list of loaded WAD URLs
    var _stats = { wads: 0, files: 0, bytes: 0, served: 0 };
    var _blobUrls = [];    // track all created blob URLs for cleanup

    // Keep originals for fallthrough
    var _OrigXHR = window.XMLHttpRequest;
    var _origFetch = window.fetch;
    var _patched = false;

    // =========================================================================
    // WAD Parsing
    // =========================================================================

    function parseWad(arrayBuffer) {
        var view = new DataView(arrayBuffer);

        // Read manifest length (4 bytes, little-endian)
        var manifestLen = view.getUint32(0, true);

        // Read manifest JSON
        var manifestBytes = new Uint8Array(arrayBuffer, 4, manifestLen);
        var manifestJson = new TextDecoder('utf-8').decode(manifestBytes);
        var manifest = JSON.parse(manifestJson);

        if (!manifest.files || !Array.isArray(manifest.files)) {
            throw new Error('Invalid WAD: manifest missing files array');
        }

        // Register all entries
        for (var i = 0; i < manifest.files.length; i++) {
            var entry = manifest.files[i];
            _entries[entry.name] = {
                buffer: arrayBuffer,
                offset: entry.offset,
                size: entry.size
            };
        }

        _stats.files = Object.keys(_entries).length;
        _stats.bytes += arrayBuffer.byteLength;

        return manifest;
    }

    // =========================================================================
    // File Access
    // =========================================================================

    // Normalize a URL/path to match WAD entry names
    // Strips leading ./ and protocol/host, converts backslashes
    function normalizePath(url) {
        var path = url.replace(/\\/g, '/');
        // Strip protocol + host (for absolute URLs on same origin)
        try {
            // if url starts with a protocol, parse it and check if it's same-origin
            if (/^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(path)) {
                var parsed = new URL(path, window.location.href);
                if (parsed.origin === window.location.origin) {
                    path = parsed.pathname;
                }
            }
        } catch(e) {}
        // Strip leading ./ or /
        path = path.replace(/^(\.\/|\/)/, '');
        return path;
    }

    function has(filename) {
        return normalizePath(filename) in _entries;
    }

    function getEntry(filename) {
        var key = normalizePath(filename);
        var entry = _entries[key];
        if (!entry) return null;
        return entry;
    }

    function get(filename) {
        var entry = getEntry(filename);
        if (!entry) return null;
        _stats.served++;
        return entry.buffer.slice(entry.offset, entry.offset + entry.size);
    }

    function getText(filename) {
        var buf = get(filename);
        if (!buf) return null;
        return new TextDecoder('utf-8').decode(buf);
    }

    function getBlob(filename, mimeType) {
        var buf = get(filename);
        if (!buf) return null;
        return new Blob([buf], { type: mimeType || guessMimeType(filename) });
    }

    function getURL(filename, mimeType) {
        var blob = getBlob(filename, mimeType);
        if (!blob) return null;
        var url = URL.createObjectURL(blob);
        _blobUrls.push({ file: filename, url: url });
        return url;
    }

    function blobs() {
        return _blobUrls.map(function(b) { return { file: b.file, url: b.url }; });
    }

    function revokeAll() {
        var count = _blobUrls.length;
        for (var i = 0; i < _blobUrls.length; i++) {
            URL.revokeObjectURL(_blobUrls[i].url);
        }
        _blobUrls.length = 0;
        console.log('[WadLoader] Revoked ' + count + ' blob URL(s)');
        return count;
    }

    function list() {
        return Object.keys(_entries).sort();
    }

    function stats() {
        return Object.assign({}, _stats);
    }

    // =========================================================================
    // MIME Type Guessing
    // =========================================================================

    function guessMimeType(filename) {
        var ext = filename.split('.').pop().toLowerCase();
        var types = {
            // Text
            'txt': 'text/plain', 'json': 'application/json',
            'xml': 'application/xml', 'html': 'text/html',
            'css': 'text/css', 'js': 'application/javascript',
            'glsl': 'text/plain', 'vert': 'text/plain', 'frag': 'text/plain',
            'csv': 'text/csv', 'svg': 'image/svg+xml',
            // Images
            'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg',
            'gif': 'image/gif', 'webp': 'image/webp', 'bmp': 'image/bmp',
            'ico': 'image/x-icon',
            // Audio
            'mp3': 'audio/mpeg', 'wav': 'audio/wav', 'ogg': 'audio/ogg',
            'flac': 'audio/flac', 'aac': 'audio/aac',
            // Video
            'mp4': 'video/mp4', 'webm': 'video/webm',
            // 3D / Binary
            'fbx': 'application/octet-stream', 'obj': 'text/plain',
            'gltf': 'model/gltf+json', 'glb': 'model/gltf-binary',
            'bin': 'application/octet-stream',
            // Archives
            'wad': 'application/octet-stream',
            'zip': 'application/zip',
        };
        return types[ext] || 'application/octet-stream';
    }

    // =========================================================================
    // HTML Asset Rewriting (for iframe srcdoc)
    // =========================================================================
    // When HTML is loaded from the WAD into an iframe via srcdoc, embedded
    // src="..." references (images, audio, etc.) can't resolve because srcdoc
    // has no base URL. This rewrites those references to blob URLs from the WAD.

    function rewriteHtmlAssets(html, sourceFile) {
        // Determine the directory of the source file for resolving relative paths
        var dir = '';
        var lastSlash = sourceFile.lastIndexOf('/');
        if (lastSlash >= 0) dir = sourceFile.substring(0, lastSlash + 1);

        // Rewrite src="..." and href="..." attributes
        return html.replace(/(src|href)\s*=\s*"([^"]+)"/gi, function(match, attr, path) {
            // Skip data URIs, absolute URLs, and anchors
            if (/^(data:|https?:|\/\/|#)/.test(path)) return match;

            // Resolve relative path against the source file's directory
            var resolved = dir + path;
            // Also try without the directory (in case paths are already WAD-relative)
            if (has(resolved)) {
                return attr + '="' + getURL(resolved) + '"';
            } else if (has(path)) {
                return attr + '="' + getURL(path) + '"';
            }

            // Not in WAD — leave unchanged
            return match;
        });
    }

    // =========================================================================
    // XMLHttpRequest Patch
    // =========================================================================

    function PatchedXHR() {
        this._wadUrl = null;
        this._wadEntry = null;
        this._method = null;
        this._async = true;
        this._responseType = '';
        this._requestHeaders = {};
        this._realXHR = null;

        // Standard XHR properties
        this.readyState = 0;
        this.status = 0;
        this.statusText = '';
        this.response = null;
        this.responseText = '';
        this.responseURL = '';

        // Event handlers (property-based)
        this.onreadystatechange = null;
        this.onload = null;
        this.onerror = null;
        this.onprogress = null;
        this.onloadend = null;
        this.ontimeout = null;
        this.onabort = null;
        this.onloadstart = null;

        // Event listeners (addEventListener-based)
        this._listeners = {};
    }

    PatchedXHR.prototype.addEventListener = function(type, fn) {
        if (!this._listeners[type]) this._listeners[type] = [];
        this._listeners[type].push(fn);
        if (this._realXHR) this._realXHR.addEventListener(type, fn);
    };

    PatchedXHR.prototype.removeEventListener = function(type, fn) {
        if (this._listeners[type]) {
            this._listeners[type] = this._listeners[type].filter(function(f) { return f !== fn; });
        }
        if (this._realXHR) this._realXHR.removeEventListener(type, fn);
    };

    PatchedXHR.prototype._fireEvent = function(type, event) {
        var prop = 'on' + type;
        if (this[prop]) this[prop](event || {});
        if (this._listeners[type]) {
            for (var i = 0; i < this._listeners[type].length; i++) {
                this._listeners[type][i].call(this, event || {});
            }
        }
    };

    PatchedXHR.prototype.open = function(method, url, async) {
        this._method = method;
        this._wadUrl = url;
        this._async = async !== false;
        this._wadEntry = getEntry(url);

        if (!this._wadEntry) {
            // Not in WAD — create a real XHR for fallthrough
            this._realXHR = new _OrigXHR();
            this._realXHR.open(method, url, this._async);
            this._proxyRealXHR();
        }
    };

    PatchedXHR.prototype.send = function(data) {
        if (this._realXHR) {
            // Fallthrough to real XHR
            if (this._responseType) {
                this._realXHR.responseType = this._responseType;
            }
            for (var h in this._requestHeaders) {
                this._realXHR.setRequestHeader(h, this._requestHeaders[h]);
            }
            this._realXHR.send(data);
            return;
        }

        // Serve from WAD
        var self = this;
        var buffer = get(this._wadUrl);

        self.status = 200;
        self.statusText = 'OK (WAD)';
        self.responseURL = self._wadUrl;

        // Build response based on responseType
        var responseType = self._responseType || '';

        if (responseType === 'arraybuffer') {
            self.response = buffer;
        } else if (responseType === 'blob') {
            self.response = new Blob([buffer], { type: guessMimeType(self._wadUrl) });
        } else if (responseType === 'json') {
            var text = new TextDecoder('utf-8').decode(buffer);
            self.responseText = text;
            try { self.response = JSON.parse(text); }
            catch(e) { self.response = null; }
        } else {
            // Default: text
            var text = new TextDecoder('utf-8').decode(buffer);
            self.responseText = text;
            self.response = text;
        }

        // Fire readyState transitions
        function fireState(state) {
            self.readyState = state;
            self._fireEvent('readystatechange');
        }

        if (self._async) {
            // Async: schedule via microtask to match real XHR behavior
            Promise.resolve().then(function() {
                fireState(1); // OPENED
                fireState(2); // HEADERS_RECEIVED
                fireState(3); // LOADING
                self._fireEvent('progress', { loaded: buffer.byteLength, total: buffer.byteLength });
                fireState(4); // DONE
                self._fireEvent('load');
                self._fireEvent('loadend');
            });
        } else {
            // Sync: fire immediately
            fireState(1);
            fireState(2);
            fireState(3);
            fireState(4);
            self._fireEvent('load');
            self._fireEvent('loadend');
        }
    };

    PatchedXHR.prototype.setRequestHeader = function(name, value) {
        this._requestHeaders[name] = value;
        if (this._realXHR) this._realXHR.setRequestHeader(name, value);
    };

    PatchedXHR.prototype.getResponseHeader = function(name) {
        if (this._realXHR) return this._realXHR.getResponseHeader(name);
        if (this._wadEntry) {
            var lower = name.toLowerCase();
            if (lower === 'content-length') return '' + this._wadEntry.size;
            if (lower === 'content-type') return guessMimeType(this._wadUrl);
        }
        return null;
    };

    PatchedXHR.prototype.getAllResponseHeaders = function() {
        if (this._realXHR) return this._realXHR.getAllResponseHeaders();
        if (this._wadEntry) {
            return 'content-type: ' + guessMimeType(this._wadUrl) + '\r\n' +
                   'content-length: ' + this._wadEntry.size + '\r\n';
        }
        return '';
    };

    PatchedXHR.prototype.abort = function() {
        if (this._realXHR) this._realXHR.abort();
    };

    PatchedXHR.prototype.overrideMimeType = function(mime) {
        if (this._realXHR) this._realXHR.overrideMimeType(mime);
    };

    // Proxy events from real XHR back to our wrapper
    PatchedXHR.prototype._proxyRealXHR = function() {
        var self = this;
        var real = this._realXHR;

        real.onreadystatechange = function() {
            self.readyState = real.readyState;
            if (real.readyState === 4) {
                self.status = real.status;
                self.statusText = real.statusText;
                self.response = real.response;
                self.responseURL = real.responseURL;
                try { self.responseText = real.responseText; } catch(e) {}
            }
            self._fireEvent('readystatechange');
        };
        real.onload = function(e) { self._fireEvent('load', e); };
        real.onerror = function(e) { self._fireEvent('error', e); };
        real.onprogress = function(e) { self._fireEvent('progress', e); };
        real.onloadend = function(e) { self._fireEvent('loadend', e); };
        real.ontimeout = function(e) { self._fireEvent('timeout', e); };
        real.onabort = function(e) { self._fireEvent('abort', e); };
        real.onloadstart = function(e) { self._fireEvent('loadstart', e); };
    };

    // responseType is a setter that may be called before send()
    Object.defineProperty(PatchedXHR.prototype, 'responseType', {
        get: function() {
            if (this._realXHR) return this._realXHR.responseType;
            return this._responseType;
        },
        set: function(val) {
            this._responseType = val;
            if (this._realXHR) this._realXHR.responseType = val;
        }
    });

    // =========================================================================
    // fetch() Patch
    // =========================================================================

    function patchedFetch(input, init) {
        var url = (typeof input === 'string') ? input : (input && input.url ? input.url : '');

        if (has(url)) {
            var buffer = get(url);
            var mime = guessMimeType(url);
            var blob = new Blob([buffer], { type: mime });
            var response = new Response(blob, {
                status: 200,
                statusText: 'OK (WAD)',
                headers: {
                    'Content-Type': mime,
                    'Content-Length': '' + buffer.byteLength,
                }
            });
            return Promise.resolve(response);
        }

        // Fallthrough to real fetch
        return _origFetch.apply(window, arguments);
    }

    // =========================================================================
    // Patching
    // =========================================================================

    // Patch the `src` setter on an element prototype (Image, Audio, etc.)
    // so that setting src to a WAD path serves from memory via blob URL
    function patchSrcProperty(proto, label) {
        var descriptor = Object.getOwnPropertyDescriptor(proto, 'src');
        if (!descriptor || !descriptor.set) return;

        var origSet = descriptor.set;
        var origGet = descriptor.get;

        Object.defineProperty(proto, 'src', {
            get: origGet,
            set: function(val) {
                if (val && has(val)) {
                    var blobUrl = getURL(val);
                    origSet.call(this, blobUrl);
                } else {
                    origSet.call(this, val);
                }
            },
            enumerable: descriptor.enumerable,
            configurable: descriptor.configurable,
        });
    }

    function applyPatches() {
        if (_patched) return;
        window.XMLHttpRequest = PatchedXHR;
        window.fetch = patchedFetch;

        // Patch element src setters for direct asset loading
        //   new Image(); img.src = "assets/tex.png"
        //   new Audio("assets/sound.mp3")
        //   video.src = "assets/clip.mp4"
        patchSrcProperty(HTMLImageElement.prototype, 'Image');
        if (typeof HTMLAudioElement !== 'undefined') {
            patchSrcProperty(HTMLAudioElement.prototype, 'Audio');
        }
        if (typeof HTMLMediaElement !== 'undefined') {
            patchSrcProperty(HTMLMediaElement.prototype, 'Media');
        }
        if (typeof HTMLSourceElement !== 'undefined') {
            patchSrcProperty(HTMLSourceElement.prototype, 'Source');
        }

        // IFrame needs special handling — use srcdoc instead of blob URL
        // so contentDocument access works (blob URLs create opaque origins).
        // Also rewrites src/href attributes inside the HTML so embedded images,
        // audio, etc. load from the WAD via blob URLs.
        if (typeof HTMLIFrameElement !== 'undefined') {
            var iframeDesc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src');
            if (iframeDesc && iframeDesc.set) {
                var origIframeSrcSet = iframeDesc.set;
                Object.defineProperty(HTMLIFrameElement.prototype, 'src', {
                    get: iframeDesc.get,
                    set: function(val) {
                        if (val && has(val)) {
                            var html = getText(val);
                            this.srcdoc = rewriteHtmlAssets(html, val);
                        } else {
                            origIframeSrcSet.call(this, val);
                        }
                    },
                    enumerable: iframeDesc.enumerable,
                    configurable: iframeDesc.configurable,
                });
            }
        }

        _patched = true;
    }

    // =========================================================================
    // Load
    // =========================================================================

    function load() {
        var urls = Array.prototype.slice.call(arguments);

        var promises = urls.map(function(url) {
            return _origFetch(url)
                .then(function(response) {
                    if (!response.ok) throw new Error('HTTP ' + response.status);
                    return response.arrayBuffer();
                })
                .then(function(buffer) {
                    var manifest = parseWad(buffer);
                    _loaded.push(url);
                    _stats.wads++;
                    console.log('[WadLoader] Loaded ' + url + ' (' + manifest.files.length + ' files, ' +
                        (buffer.byteLength / 1024).toFixed(1) + ' KB)');
                    return manifest;
                })
                .catch(function(err) {
                    console.warn('[WadLoader] Skipping ' + url + ' (' + err.message + ') — assets will load normally');
                    return null;
                });
        });

        return Promise.all(promises).then(function(results) {
            var manifests = results.filter(function(m) { return m !== null; });
            if (manifests.length > 0) {
                applyPatches();
                // Re-trigger all src attributes already in the DOM so images/audio
                // that were set before the WAD loaded get intercepted
                document.querySelectorAll('[src]').forEach(function(el) {
                    el.src = el.getAttribute('src');
                });
                console.log('[WadLoader] Ready — ' + _stats.files + ' files available from ' + _stats.wads + ' WAD(s)');
            } else {
                console.log('[WadLoader] No WADs loaded — using normal file loading');
            }
            return manifests;
        });
    }

    // =========================================================================
    // Public API
    // =========================================================================

    return {
        load: load,
        has: has,
        get: get,
        getText: getText,
        getBlob: getBlob,
        getURL: getURL,
        list: list,
        stats: stats,
        blobs: blobs,
        revokeAll: revokeAll,
    };

})();
