#!/usr/bin/env node
// =============================================================================
// wadpack.mjs — Web Asset Directory Packer
// =============================================================================
// Packs multiple asset files into a single .wad binary archive with a JSON
// manifest header. Inspired by the WAD format from classic id Software games.
//
// Format:
//   [4 bytes]  Manifest length (uint32 LE)
//   [N bytes]  Manifest JSON (UTF-8)
//   [...]      Raw file data (concatenated, byte-aligned)
//
// Manifest structure:
//   {
//     "version": 1,
//     "files": [
//       { "name": "models/tank.fbx.png", "offset": 1248, "size": 34572 },
//       { "name": "shaders/glow.glsl",   "offset": 35820, "size": 891 },
//       ...
//     ]
//   }
//
// Usage:
//   node wadpack.mjs pack <directory> [output.wad]    Pack directory → WAD
//   node wadpack.mjs list <input.wad>                 List WAD contents
//   node wadpack.mjs extract <input.wad> <filename>   Extract a file from WAD
//
// Options:
//   --out <file>          Output path (pack/extract)
//   --filter <glob>       Only pack files matching pattern (e.g. "*.glsl")
//   --exclude <glob>      Skip files matching pattern (e.g. "*.bak")
//   --verbose             Print processing details
//   --help, -h            Show this help
//
// Examples:
//   node wadpack.mjs pack ./assets game.wad
//   node wadpack.mjs list game.wad
//   node wadpack.mjs extract game.wad models/tank.fbx.png --out ./tank.fbx.png
// =============================================================================

import { readFileSync, writeFileSync, existsSync, statSync, readdirSync, mkdirSync } from 'fs';
import { resolve, relative, dirname, basename, extname, join } from 'path';

// =============================================================================
// File Discovery
// =============================================================================

// Recursively walk a directory and return all file paths (relative to root)
function walkDir(dir, rootDir = dir) {
    const results = [];
    const entries = readdirSync(dir, { withFileTypes: true });

    for (const entry of entries) {
        const fullPath = join(dir, entry.name);
        if (entry.isDirectory()) {
            results.push(...walkDir(fullPath, rootDir));
        } else if (entry.isFile()) {
            // Store path with forward slashes for cross-platform consistency
            results.push(relative(rootDir, fullPath).replace(/\\/g, '/'));
        }
    }

    return results.sort();
}

// Simple glob matching (supports * and ** patterns)
// If the pattern has no path separator, auto-promote to match in any directory
// e.g. "*.psd" becomes "**/*.psd" so it matches "textures/ground.psd"
function matchGlob(filename, pattern) {
    // Auto-promote patterns without path separators
    if (!pattern.includes('/') && !pattern.includes('**')) {
        pattern = '**/' + pattern;
    }
    // Convert glob to regex, handling **/ as a unit (zero or more path segments)
    let regex = '';
    let i = 0;
    while (i < pattern.length) {
        if (pattern[i] === '*' && pattern[i + 1] === '*' && pattern[i + 2] === '/') {
            regex += '(.*/)?';  // **/ = zero or more path segments (including none)
            i += 3;
        } else if (pattern[i] === '*' && pattern[i + 1] === '*') {
            regex += '.*';      // ** at end = match anything
            i += 2;
        } else if (pattern[i] === '*') {
            regex += '[^/]*';   // * = match within one segment
            i += 1;
        } else if ('.+^${}()|[]\\'.includes(pattern[i])) {
            regex += '\\' + pattern[i];  // escape regex special chars
            i += 1;
        } else {
            regex += pattern[i];
            i += 1;
        }
    }
    return new RegExp('^' + regex + '$', 'i').test(filename);
}

// =============================================================================
// WAD Writing (shared by pack and append)
// =============================================================================

function writeWad(entries, dataBuffers, outputPath) {
    // Build manifest — first pass to calculate offsets
    // We need to know manifest size before we can calculate offsets,
    // but offset values affect manifest size. Solve with two passes.
    let manifest = { version: 1, files: entries };
    let manifestJson = JSON.stringify(manifest);
    let manifestSize = Buffer.byteLength(manifestJson, 'utf8');

    // Data starts after: 4 bytes (manifest length) + manifest
    let dataStart = 4 + manifestSize;

    // Assign offsets
    let cursor = dataStart;
    for (const entry of entries) {
        entry.offset = cursor;
        cursor += entry.size;
    }

    // Re-serialize manifest with correct offsets (size may change due to offset digits)
    manifestJson = JSON.stringify(manifest);
    const newManifestSize = Buffer.byteLength(manifestJson, 'utf8');

    // If manifest size changed (offset digits grew), recalculate
    if (newManifestSize !== manifestSize) {
        manifestSize = newManifestSize;
        dataStart = 4 + manifestSize;
        cursor = dataStart;
        for (const entry of entries) {
            entry.offset = cursor;
            cursor += entry.size;
        }
        manifestJson = JSON.stringify(manifest);
    }

    // Build the WAD buffer
    const manifestBuf = Buffer.from(manifestJson, 'utf8');
    const headerBuf = Buffer.alloc(4);
    headerBuf.writeUInt32LE(manifestBuf.length, 0);

    const wadBuffer = Buffer.concat([headerBuf, manifestBuf, ...dataBuffers]);
    writeFileSync(outputPath, wadBuffer);

    return wadBuffer;
}

// =============================================================================
// Pack — directory → WAD
// =============================================================================

function pack(inputDir, outputPath, opts) {
    const log = opts.verbose ? (...a) => console.log(...a) : () => {};

    if (!existsSync(inputDir) || !statSync(inputDir).isDirectory()) {
        console.error(`Not a directory: ${inputDir}`);
        process.exit(1);
    }

    // Discover files (paths relative to CWD so directory structure is preserved)
    let files = walkDir(inputDir, process.cwd());
    log(`\n📂 Scanning: ${relative(process.cwd(), inputDir)}`);
    log(`   Found ${files.length} file(s)`);

    // Apply filters
    if (opts.filter.length > 0) {
        files = files.filter(f => opts.filter.some(p => matchGlob(f, p)));
        log(`   After filter [${opts.filter.join(', ')}]: ${files.length} file(s)`);
    }
    if (opts.exclude.length > 0) {
        files = files.filter(f => !opts.exclude.some(p => matchGlob(f, p)));
        log(`   After exclude [${opts.exclude.join(', ')}]: ${files.length} file(s)`);
    }

    if (files.length === 0) {
        console.error('No files to pack.');
        process.exit(1);
    }

    // Read all file data
    const entries = [];
    const dataBuffers = [];

    for (const file of files) {
        // file is already relative to CWD, so read directly
        const data = readFileSync(file);
        entries.push({
            name: file,
            size: data.length,
            offset: 0,  // filled in by writeWad
        });
        dataBuffers.push(data);
        log(`   📄 ${file} (${formatSize(data.length)})`);
    }

    // Write WAD
    const wadBuffer = writeWad(entries, dataBuffers, outputPath);
    const totalDataSize = dataBuffers.reduce((sum, b) => sum + b.length, 0);

    console.log(`\n✅ WAD packed successfully`);
    console.log(`   Output:   ${basename(outputPath)} (${formatSize(wadBuffer.length)})`);
    console.log(`   Files:    ${entries.length}`);
    console.log(`   Assets:   ${formatSize(totalDataSize)}`);
    console.log('');
}

// =============================================================================
// List — show WAD contents
// =============================================================================

function list(inputPath, opts) {
    const { manifest, buffer } = readWad(inputPath);

    const totalSize = manifest.files.reduce((sum, f) => sum + f.size, 0);

    console.log(`\n📦 ${basename(inputPath)} (${formatSize(buffer.length)})`);
    console.log(`   Format version: ${manifest.version}`);
    console.log(`   Files: ${manifest.files.length}`);
    console.log(`   Total asset data: ${formatSize(totalSize)}`);
    console.log('');

    // Column headers
    const nameWidth = Math.max(4, ...manifest.files.map(f => f.name.length));
    console.log(`   ${'Name'.padEnd(nameWidth)}  ${'Size'.padStart(10)}  ${'Offset'.padStart(10)}`);
    console.log(`   ${'─'.repeat(nameWidth)}  ${'─'.repeat(10)}  ${'─'.repeat(10)}`);

    for (const file of manifest.files) {
        console.log(`   ${file.name.padEnd(nameWidth)}  ${formatSize(file.size).padStart(10)}  ${file.offset.toString().padStart(10)}`);
    }
    console.log('');
}

// =============================================================================
// Extract — pull a file out of a WAD
// =============================================================================

function extract(inputPath, filename, outputPath, opts) {
    const { manifest, buffer } = readWad(inputPath);

    // Find the file in the manifest
    const entry = manifest.files.find(f =>
        f.name === filename || f.name === filename.replace(/\\/g, '/')
    );

    if (!entry) {
        console.error(`File not found in WAD: ${filename}`);
        console.error(`Use "wadpack list ${basename(inputPath)}" to see available files.`);
        process.exit(1);
    }

    // Extract the data slice
    const data = buffer.slice(entry.offset, entry.offset + entry.size);

    // Determine output path
    if (!outputPath) {
        outputPath = basename(entry.name);
    }

    // Ensure output directory exists
    const outDir = dirname(outputPath);
    if (outDir && outDir !== '.' && !existsSync(outDir)) {
        mkdirSync(outDir, { recursive: true });
    }

    writeFileSync(outputPath, data);

    console.log(`\n✅ Extracted: ${entry.name}`);
    console.log(`   Size:   ${formatSize(entry.size)}`);
    console.log(`   Output: ${outputPath}`);
    console.log('');
}

// =============================================================================
// Append — add/overwrite files in an existing WAD
// =============================================================================

function append(wadPath, inputPaths, opts) {
    const log = opts.verbose ? (...a) => console.log(...a) : () => {};

    // Read existing WAD
    const { manifest, buffer } = readWad(wadPath);

    log(`\n📦 Existing WAD: ${basename(wadPath)} (${manifest.files.length} files)`);

    // Extract existing file data from the WAD buffer
    const existingEntries = {};  // name → Buffer
    for (const entry of manifest.files) {
        existingEntries[entry.name] = Buffer.from(buffer.slice(entry.offset, entry.offset + entry.size));
    }

    // Collect new files to add
    let added = 0;
    let replaced = 0;

    for (const inputPath of inputPaths) {
        if (!existsSync(inputPath)) {
            console.warn(`  ⚠  File not found: ${inputPath}`);
            continue;
        }

        const stat = statSync(inputPath);

        if (stat.isDirectory()) {
            // Add all files from directory
            const dirFiles = walkDir(inputPath, process.cwd());
            for (const file of dirFiles) {
                const data = readFileSync(file);
                if (existingEntries[file]) {
                    replaced++;
                    log(`   🔄 Replacing: ${file} (${formatSize(data.length)})`);
                } else {
                    added++;
                    log(`   ➕ Adding: ${file} (${formatSize(data.length)})`);
                }
                existingEntries[file] = data;
            }
        } else {
            // Single file — use CWD-relative path
            const name = relative(process.cwd(), resolve(inputPath)).replace(/\\/g, '/');
            const data = readFileSync(inputPath);
            if (existingEntries[name]) {
                replaced++;
                log(`   🔄 Replacing: ${name} (${formatSize(data.length)})`);
            } else {
                added++;
                log(`   ➕ Adding: ${name} (${formatSize(data.length)})`);
            }
            existingEntries[name] = data;
        }
    }

    // Rebuild WAD with merged entries
    const names = Object.keys(existingEntries).sort();
    const entries = [];
    const dataBuffers = [];

    for (const name of names) {
        const data = existingEntries[name];
        entries.push({ name, size: data.length, offset: 0 });
        dataBuffers.push(data);
    }

    const wadBuffer = writeWad(entries, dataBuffers, wadPath);
    const totalDataSize = dataBuffers.reduce((sum, b) => sum + b.length, 0);

    console.log(`\n✅ WAD updated`);
    console.log(`   Output:    ${basename(wadPath)} (${formatSize(wadBuffer.length)})`);
    console.log(`   Files:     ${entries.length} total`);
    console.log(`   Added:     ${added}`);
    console.log(`   Replaced:  ${replaced}`);
    console.log(`   Assets:    ${formatSize(totalDataSize)}`);
    console.log('');
}

// =============================================================================
// WAD Reading Helper
// =============================================================================

function readWad(inputPath) {
    if (!existsSync(inputPath)) {
        console.error(`File not found: ${inputPath}`);
        process.exit(1);
    }

    const buffer = readFileSync(inputPath);

    if (buffer.length < 4) {
        console.error('Invalid WAD file: too small');
        process.exit(1);
    }

    // Read manifest length
    const manifestLen = buffer.readUInt32LE(0);

    if (4 + manifestLen > buffer.length) {
        console.error(`Invalid WAD file: manifest length (${manifestLen}) exceeds file size`);
        process.exit(1);
    }

    // Parse manifest
    const manifestJson = buffer.slice(4, 4 + manifestLen).toString('utf8');
    let manifest;
    try {
        manifest = JSON.parse(manifestJson);
    } catch (e) {
        console.error('Invalid WAD file: manifest is not valid JSON');
        process.exit(1);
    }

    if (!manifest.files || !Array.isArray(manifest.files)) {
        console.error('Invalid WAD file: manifest missing files array');
        process.exit(1);
    }

    return { manifest, buffer };
}

// =============================================================================
// Utilities
// =============================================================================

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// =============================================================================
// CLI
// =============================================================================

function printUsage() {
    console.log(`
  wadpack.mjs — Web Asset Directory Packer

  Usage:
    node wadpack.mjs pack <directory> [output.wad]     Pack directory → WAD
    node wadpack.mjs append <input.wad> <paths...>     Add/overwrite files in a WAD
    node wadpack.mjs list <input.wad>                  List WAD contents
    node wadpack.mjs extract <input.wad> <filename>    Extract a file from WAD

  Options:
    --out <file>          Output path for extract
    --filter <glob>       Only pack files matching pattern (e.g. "*.glsl")
    --exclude <glob>      Exclude files matching pattern (e.g. "*.bak")
    --verbose             Print processing details
    -h, --help            Show this help

  Examples:
    node wadpack.mjs pack ./assets game.wad
    node wadpack.mjs append game.wad ./assets/new_model.fbx
    node wadpack.mjs append game.wad ./extra_assets/
    node wadpack.mjs list game.wad
    node wadpack.mjs extract game.wad assets/models/tank.fbx
    node wadpack.mjs pack ./assets game.wad --exclude "*.psd" --exclude "*.bak"
`);
}

function parseArgs(argv) {
    const args = argv.slice(2);
    const opts = {
        command: null,
        input: null,
        output: null,
        filename: null,      // for extract
        appendPaths: [],     // for append
        filter: [],
        exclude: [],
        verbose: false,
    };
    const positional = [];

    for (let i = 0; i < args.length; i++) {
        switch (args[i]) {
            case '--out':     opts.output = resolve(args[++i]); break;
            case '--filter':  opts.filter.push(args[++i]); break;
            case '--exclude': opts.exclude.push(args[++i]); break;
            case '--verbose': opts.verbose = true; break;
            case '--help': case '-h': printUsage(); process.exit(0);
            default:
                if (args[i].startsWith('-')) {
                    console.error(`Unknown option: ${args[i]}`);
                    process.exit(1);
                }
                positional.push(args[i]);
        }
    }

    if (positional.length < 2) { printUsage(); process.exit(1); }

    opts.command = positional[0];
    opts.input = resolve(positional[1]);

    if (opts.command === 'pack') {
        opts.output = positional[2]
            ? resolve(positional[2])
            : resolve(basename(positional[1]) + '.wad');
    } else if (opts.command === 'extract') {
        if (!positional[2]) {
            console.error('Extract requires a filename. Usage: wadpack extract <wad> <filename>');
            process.exit(1);
        }
        opts.filename = positional[2];
        // --out overrides, otherwise use the base filename
        if (!opts.output) {
            opts.output = basename(positional[2]);
        }
    } else if (opts.command === 'append') {
        if (positional.length < 3) {
            console.error('Append requires at least one file or directory. Usage: wadpack append <wad> <paths...>');
            process.exit(1);
        }
        opts.appendPaths = positional.slice(2).map(p => resolve(p));
    }

    return opts;
}

// =============================================================================
// Run
// =============================================================================

const opts = parseArgs(process.argv);

switch (opts.command) {
    case 'pack':
        pack(opts.input, opts.output, opts);
        break;
    case 'list':
        list(opts.input, opts);
        break;
    case 'extract':
        extract(opts.input, opts.filename, opts.output, opts);
        break;
    case 'append':
        append(opts.input, opts.appendPaths, opts);
        break;
    default:
        console.error(`Unknown command: ${opts.command}`);
        printUsage();
        process.exit(1);
}
